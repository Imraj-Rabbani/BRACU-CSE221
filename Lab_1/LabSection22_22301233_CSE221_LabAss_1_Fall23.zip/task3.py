input_file = open("input3.txt","r")
output_file = open("output3.txt","w")

num = int(input_file.readline())

second_line = input_file.readline().split(" ")
ID = list(map(int,second_line))

third_line = input_file.readline().split(" ")
marks = list(map(int,third_line))

def sort(marks,ID):
    for i in range(len(marks)):
        flag = True
        for j in range(len(marks)-1-i):
            if marks[j]<marks[j+1]:
                marks[j], marks[j+1] = marks[j+1], marks[j]
                ID[j], ID[j+1] = ID[j+1], ID[j]
                flag=False
        if flag == True:
            break


def output(marks,ID):
    for i in range(num):
        if i == num-1:
            output_file.write(f"ID: {ID[i]} Mark: {marks[i]}")
            break
        if marks[i]==marks[i+1]: 
            for j in range(i,num):
                for k in range(j+1,num):
                    if marks[j]==marks[k]:
                        if ID[j]>ID[k]:
                            ID[j],ID[k]=ID[k],ID[j]
        output_file.write(f"ID: {ID[i]} Mark: {marks[i]}\n")

sort(marks,ID)
output(marks,ID)

input_file.close()
output_file.close()